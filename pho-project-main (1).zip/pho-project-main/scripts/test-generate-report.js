#!/usr/bin/env node
const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');

(async () => {
  const html = `<!DOCTYPE html><html><head></head><body>
    <button id="generate-report">Generate Report Now</button>
    <button id="download-pdf" disabled>Download</button>
    <div id="report-view"></div>
    <script src="/ai-report.js"></script>
  </body></html>`;

  const dom = new JSDOM(html, {
    url: 'https://example.com',
    runScripts: 'dangerously',
    resources: 'usable',
    pretendToBeVisual: true,
    beforeParse(window) {
      // Provide a minimal APP_CONFIG
      window.APP_CONFIG = {
        OPENAI_API_KEY: 'sk-test',
        OPENAI_API_ENDPOINT: 'https://api.openai.com/v1/chat/completions',
        OPENAI_MODEL: 'gpt-4o-mini',
        BRAND: { LOGO_PATH: '/images/LOGO PH.png' },
        PDF: { DEFAULT_FONT: 'Roboto' },
        EXPERT_PROMPT_TEXT: 'اكتب تقرير دراسة جدوى احترافيًا وشاملًا بأسلوب أكاديمي عربي رصين، مع تحليل متعمّق وتنسيق محاذاة كاملة، 300–500+ كلمة لكل قسم، وإجمالي يتجاوز 25 صفحة.'
      };
      // Stub fetch for OpenAI and image loader
      window.fetch = async (input, init) => {
        if (typeof input === 'string' && input.includes('/v1/chat/completions')) {
          // Inspect request body to ensure correct Chat Completions formatting
          const body = JSON.parse(init.body);
          if (body.response_format) throw new Error('Found forbidden response_format parameter');
          if (body.text_format) throw new Error('Found forbidden text_format parameter');
          if (body['text.format'] !== undefined) throw new Error('text.format must be removed');
          if (!Array.isArray(body.messages)) throw new Error('messages array is required');
          if (body.input) throw new Error('input field must be replaced by messages');
          // Return a minimal successful Chat Completions payload that ai-report.js can parse
          const assistantContent = JSON.stringify({
            title: 'Test Report',
            language: 'en',
            executiveSummary: 'This is a test summary.',
            coverPage: {
              studyType: 'Preliminary Feasibility Study',
              projectName: 'Demo Project',
              projectDescription: 'Short description',
              visionMission: 'Vision & Mission',
              basicInfo: { sector: 'Tech', projectType: 'Service', specifiedProjectType: '', country: 'US', city: 'NY', area: '', fundingMethod: 'Self', personalContribution: '10000', loanAmount: '0', interestValue: '0', currency: 'USD', totalCapital: '10000', loanMonths: '0', targetAudience: 'SMB', projectStatus: 'Idea', duration: '12', durationUnit: 'months' },
              author: { fullName: 'Alex', email: 'a@example.com' },
              timestamp: { iso: new Date().toISOString(), date: '2025-01-01', time: '10:00:00' },
              confidentiality: 'Confidential'
            },
            sections: [
              { id: '1-1', title: 'Project Overview', content: 'Intro content', tables: [], wordCount: 2 }
            ],
            comparison: { enabled: false, table: null, notes: '' },
            keywords: ['test'],
            disclaimers: ['For testing only']
          });
          return new Response(JSON.stringify({
            id: 'chatcmpl-test',
            object: 'chat.completion',
            created: Math.floor(Date.now() / 1000),
            model: body.model || 'gpt-4o-mini',
            choices: [
              {
                index: 0,
                message: { role: 'assistant', content: assistantContent },
                finish_reason: 'stop'
              }
            ],
            usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 }
          }), { status: 200, headers: { 'Content-Type': 'application/json' } });
        }
        // For images in tests, return 404 to force graceful handling
        return new Response('Not Found', { status: 404 });
      };
      // Provide a minimal pdfMake stub to avoid errors when download is clicked later
      window.pdfMake = {
        createPdf() { return { download() {} }; }
      };
      // Provide localStorage
      const store = new Map();
      window.localStorage = {
        getItem: (k) => (store.has(k) ? store.get(k) : null),
        setItem: (k, v) => store.set(k, String(v)),
        removeItem: (k) => store.delete(k),
        clear: () => store.clear(),
      };
      // Seed minimal feasibility inputs
      window.localStorage.setItem('preferredLanguage', 'en');
      window.localStorage.setItem('startFeasibilityForm', JSON.stringify({ projectName: 'Demo Project', sector: 'Tech' }));
      window.localStorage.setItem('feasibilityStudyAnswers', JSON.stringify({ q1: 'a1' }));
      window.localStorage.setItem('userInfo', JSON.stringify({ name: 'Alex', country: 'US', city: 'NY' }));
    }
  });

  // Inject ai-report.js source inline so it can run in the DOM
  const scriptContent = fs.readFileSync(path.join(__dirname, '..', 'ai-report.js'), 'utf8');
  // Execute the script content directly in the window context
  dom.window.eval(scriptContent);

  // Wait briefly for script evaluation
  await new Promise((r) => setTimeout(r, 100));

  // Prepare error capture
  const capturedErrors = [];
  const originalConsoleError = dom.window.console.error;
  dom.window.console.error = (...args) => {
    capturedErrors.push(args.map(String).join(' '));
    if (originalConsoleError) originalConsoleError.apply(dom.window.console, args);
  };

  // Run generate directly via exposed API
  const genBtn = dom.window.document.getElementById('generate-report');
  const dlBtn = dom.window.document.getElementById('download-pdf');
  const reportView = dom.window.document.getElementById('report-view');

  if (!genBtn || !dlBtn || !reportView) {
    console.error('Required elements missing from DOM');
    process.exit(1);
  }

  await dom.window.AIReport.generateReport();
  await new Promise((r) => setTimeout(r, 100));

  // Validate: no error UI, download enabled, content present
  if (dlBtn.disabled) {
    console.error('Download button is still disabled');
    process.exit(1);
  }
  if (!reportView.textContent || !reportView.textContent.includes('Test Report')) {
    console.error('Report view not populated correctly');
    process.exit(1);
  }
  // Validate presence of coverPage fields in the generated report object and sections order
  const gen = dom.window.__generatedReport;
  if (!gen || !gen.report || !gen.report.coverPage || gen.report.sections[0].id !== '1-1') {
    console.error('Report structure missing coverPage or sections order');
    process.exit(1);
  }
  if (capturedErrors.length) {
    console.error('Console errors detected: ' + capturedErrors.join(' | '));
    process.exit(1);
  }

  console.log('OK: report generated successfully via Chat Completions.');
})();
