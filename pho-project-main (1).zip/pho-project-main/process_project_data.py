from __future__ import annotations

from typing import Any, Dict, Iterable, Optional


def _first_present_value(data: Dict[str, Any], keys: Iterable[str]) -> Any:
    """Return the first non-empty value found for any of the provided keys.

    A value is considered empty if it is None or an empty string after stripping.
    """
    for key in keys:
        if key in data:
            value = data[key]
            if value is None:
                continue
            if isinstance(value, str) and value.strip() == "":
                continue
            return value
    return None


def _to_string(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _to_float(value: Any, default: float = 0.0) -> float:
    """Parse a value into a float.

    Supports strings with commas, currency symbols, and percentage signs.
    Empty or invalid values return the provided default.
    """
    if value is None:
        return default
    if isinstance(value, (int, float)):
        try:
            return float(value)
        except (ValueError, TypeError):
            return default

    # String parsing
    text = str(value).strip()
    if text == "":
        return default

    # Remove common currency symbols and spaces
    sanitized = (
        text.replace(",", "")
        .replace("$", "")
        .replace("€", "")
        .replace("£", "")
        .replace("₦", "")  # Nigerian Naira
        .replace("₹", "")
        .replace("₵", "")
        .replace("₱", "")
        .replace("¥", "")
        .strip()
    )

    # Handle percentages like "5%"
    is_percent = False
    if sanitized.endswith("%"):
        is_percent = True
        sanitized = sanitized[:-1].strip()

    try:
        number = float(sanitized)
        # If input had a percent sign, keep the numeric percent (e.g., "5%" -> 5.0)
        return number if is_percent else number
    except (ValueError, TypeError):
        return default


def _to_int(value: Any, default: int = 0) -> int:
    number = _to_float(value, float(default))
    try:
        return int(round(number))
    except (ValueError, TypeError):
        return default


def _resolve_other(choice_value: Any, other_value: Any) -> str:
    """Return 'other_value' if 'choice_value' indicates an 'Other' selection; else the choice.

    The check is case-insensitive and treats values starting with 'other' as Other.
    """
    choice_text = _to_string(choice_value)
    if choice_text.lower().startswith("other"):
        other_text = _to_string(other_value)
        # If no other text provided, fallback to literal 'Other'
        return other_text if other_text != "" else "Other"
    return choice_text


def process_project_data(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Clean and organize raw project data into a typed dictionary.

    Input keys expected (case-sensitive, as commonly exported by forms):
      - 'Feasibility Study Type'
      - 'Sector' (+ optional text field for Other)
      - 'Project Type' (+ optional text field for Other)
      - 'Project Name'
      - 'Country'
      - 'City'
      - 'Area/Region'
      - 'Funding Method'
      - 'Personal Amount' (optional)
      - 'Loan Amount' (optional)
      - 'Interest Value' (optional)
      - 'Currency'
      - 'Total Capital' (calculated; input ignored if present)
      - 'Number of Months to Repay Loan'
      - 'Brief description of the project idea or objectives'
      - 'Target Market'
      - 'Project Status'
      - 'Expected Duration'
      - 'Time Unit'
      - 'Additional notes or special details'

    For 'Sector' and 'Project Type', if the selected value is 'Other', the function
    will look for a companion free-text field using common keys, including:
      - '<Field> - Other', '<Field> Other', '<Field> (Other)', '<Field> (specify)', '<Field> (please specify)'

    Optional numeric fields missing or invalid are defaulted to 0.

    Returns a dictionary with normalized snake_case keys and typed values.
    """

    def other_aliases(base_key: str) -> list[str]:
        return [
            f"{base_key} - Other",
            f"{base_key} Other",
            f"{base_key} (Other)",
            f"{base_key} (specify)",
            f"{base_key} (please specify)",
            f"{base_key} (Please specify)",
            f"{base_key} (Please Specify)",
            f"Other {base_key}",
        ]

    # Strings
    feasibility_study_type = _to_string(raw.get("Feasibility Study Type"))
    project_name = _to_string(raw.get("Project Name"))
    country = _to_string(raw.get("Country"))
    city = _to_string(raw.get("City"))
    area_or_region = _to_string(raw.get("Area/Region"))
    funding_method = _to_string(raw.get("Funding Method"))
    currency = _to_string(raw.get("Currency"))
    description = _to_string(raw.get("Brief description of the project idea or objectives"))
    target_market = _to_string(raw.get("Target Market"))
    project_status = _to_string(raw.get("Project Status"))
    time_unit = _to_string(raw.get("Time Unit"))
    notes = _to_string(raw.get("Additional notes or special details"))

    # Handle 'Other' values
    sector_choice = _first_present_value(raw, ["Sector"])  # main selection
    sector_other = _first_present_value(raw, other_aliases("Sector"))
    sector = _resolve_other(sector_choice, sector_other)

    project_type_choice = _first_present_value(raw, ["Project Type"])  # main selection
    project_type_other = _first_present_value(raw, other_aliases("Project Type"))
    project_type = _resolve_other(project_type_choice, project_type_other)

    # Numbers (optional ones default to 0)
    personal_amount = _to_float(raw.get("Personal Amount"), 0.0)
    loan_amount = _to_float(raw.get("Loan Amount"), 0.0)
    interest_value = _to_float(raw.get("Interest Value"), 0.0)

    # Calculated
    total_capital = personal_amount + loan_amount

    # Other numeric fields
    months_to_repay_loan = _to_int(raw.get("Number of Months to Repay Loan"), 0)
    expected_duration = _to_float(raw.get("Expected Duration"), 0.0)

    return {
        "feasibility_study_type": feasibility_study_type,
        "sector": sector,
        "project_type": project_type,
        "project_name": project_name,
        "country": country,
        "city": city,
        "area_or_region": area_or_region,
        "funding_method": funding_method,
        "personal_amount": personal_amount,
        "loan_amount": loan_amount,
        "interest_value": interest_value,
        "currency": currency,
        "total_capital": total_capital,
        "months_to_repay_loan": months_to_repay_loan,
        "description": description,
        "target_market": target_market,
        "project_status": project_status,
        "expected_duration": expected_duration,
        "time_unit": time_unit,
        "notes": notes,
    }


def process_start_feasibility_form(raw: Dict[str, Any]) -> Dict[str, Any]:
    """Process data posted from start-feasibility.html into a normalized dict.

    This function accepts a dictionary (e.g., from a POST body or form parser)
    using the names defined in start-feasibility.html and returns a clean,
    structured dictionary with snake_case keys and typed values.

    Numeric optional fields like personalContribution, loanAmount, and
    interestValue are parsed as numbers and defaulted to 0 if not provided.
    """

    # Strings
    feasibility_study_type = _to_string(raw.get("studyType"))
    project_name = _to_string(raw.get("projectName"))
    country = _to_string(raw.get("country"))
    city = _to_string(raw.get("city"))
    area_or_region = _to_string(raw.get("area"))
    funding_method = _to_string(raw.get("fundingMethod"))
    currency = _to_string(raw.get("currency"))
    description = _to_string(raw.get("projectDescription"))
    target_market = _to_string(raw.get("targetAudience"))
    project_status = _to_string(raw.get("projectStatus"))
    time_unit = _to_string(raw.get("durationUnit"))
    notes = _to_string(raw.get("notes"))

    # Handle 'Other' and empty selections for sector and project type
    sector_choice = _first_present_value(raw, ["sector"])  # main selection
    sector_other = _first_present_value(raw, ["otherSector"])  # free text when 'other'
    sector = _resolve_other(sector_choice, sector_other)

    project_type_choice = _first_present_value(raw, ["projectType"])  # main selection
    # project type may come from either "otherProjectType" (when sector is other)
    # or "specifiedProjectType" (when project type set to other)
    project_type_other = _first_present_value(raw, ["otherProjectType", "specifiedProjectType"])

    # If the main selection is empty, fall back to the free-text other value directly
    if _to_string(project_type_choice) == "":
        project_type = _to_string(project_type_other)
    else:
        project_type = _resolve_other(project_type_choice, project_type_other)

    # Numbers (optional ones default to 0)
    personal_amount = _to_float(raw.get("personalContribution"), 0.0)
    loan_amount = _to_float(raw.get("loanAmount"), 0.0)
    interest_value = _to_float(raw.get("interestValue"), 0.0)

    # Calculated
    total_capital = personal_amount + loan_amount

    # Other numeric fields
    months_to_repay_loan = _to_int(raw.get("loanMonths"), 0)
    expected_duration = _to_float(raw.get("duration"), 0.0)

    return {
        "feasibility_study_type": feasibility_study_type,
        "sector": sector,
        "project_type": project_type,
        "project_name": project_name,
        "country": country,
        "city": city,
        "area_or_region": area_or_region,
        "funding_method": funding_method,
        "personal_amount": personal_amount,
        "loan_amount": loan_amount,
        "interest_value": interest_value,
        "currency": currency,
        "total_capital": total_capital,
        "months_to_repay_loan": months_to_repay_loan,
        "description": description,
        "target_market": target_market,
        "project_status": project_status,
        "expected_duration": expected_duration,
        "time_unit": time_unit,
        "notes": notes,
    }


__all__ = ["process_project_data", "process_start_feasibility_form"]

