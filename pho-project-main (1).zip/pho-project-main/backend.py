from typing import Any, Dict, Mapping, Union


UserData = Dict[str, Union[str, int]]


def process_user_data(data: Mapping[str, Any]) -> UserData:
    """
    Organize user data into a dictionary with fixed keys and types.

    Expected keys in the input mapping:
    - 'full_name': string
    - 'email': string
    - 'gender': string
    - 'age': integer or string representation of an integer
    - 'country': string
    - 'city': string

    Returns a dictionary with the above keys where 'age' is coerced to int.
    """

    organized: UserData = {
        "full_name": data["full_name"],
        "email": data["email"],
        "gender": data["gender"],
        "age": int(data["age"]),
        "country": data["country"],
        "city": data["city"],
    }

    return organized

